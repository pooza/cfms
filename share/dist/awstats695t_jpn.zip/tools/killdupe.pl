$lastrec = "";
$count = 0;
while(<STDIN>){
	if ($_ ne $lastrec) {
		print;
		$lastrec = $_;
	} else {
		$count = $count + 1;
	}
}
print "$count\n";