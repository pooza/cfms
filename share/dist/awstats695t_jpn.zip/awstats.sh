#! /bin/sh

# 完全日本語版AWStats用サンプルshファイル
#
# ファイルパス等は自分の環境に合わせて書き直して下さい。

# httpのログファイルをデコードした上で一時ディレクトリに格納します。
# access_log.utf8は一時的にデコードしたログを保存するファイルの名前です。

cd /usr/local/awstats/tools

perl utf8_decode.pl < /var/log/access_log > /var/log/access_log.utf8

# Ver.5.0から、更新処理を別途走らせる必要ができたらしい....
cd /usr/local/awstats/wwwroot/cgi-bin

perl awstats.pl -config=hobbit.ddo.jp -update > /dev/null;

# awstats.plを走らせ、htmlファイルを出力します。
# 必須ではありませんが、awstats.plを直接参照させるよりも、htmlに出力して表示す
# る方が、良好なパフォーマンスが得られます。
perl awstats.pl -config=hobbit.ddo.jp -output > /usr/local/www/data/awstats.html.ja.utf8;
