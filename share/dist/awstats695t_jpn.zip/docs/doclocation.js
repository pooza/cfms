var doc=document.location.href;
if (doc.match(/^http/i)!=null) {
	document.write('<scr' + 'ipt language="javascript" src="/cgi-bin/pslogger.pl?loc='+escape(document.location)+'&ref='+escape(document.referrer));
	if (document.all) { document.write('&size='+document.fileSize); }
	document.write('"></scr' + 'ipt>');
}
